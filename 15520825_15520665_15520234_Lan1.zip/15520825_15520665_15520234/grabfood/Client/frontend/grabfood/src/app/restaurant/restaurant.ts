export interface Restaurant {
    _id?: string,
    name: string,
    address: string,
    email: string,
    phone: string,
    rating: number,
    facebook: string,
    products: Object[]
    
    constructor(

    ) { }
}
