﻿Yêu cầu:
+ Máy có cài đặt sẵn NodeJS, npm
+ Máy có cài đặt MongoDB chạy ở Port 27127

Cài đặt:
- Chạy Web Admin:
    + Vào thư mục: grabfood/Client/frontend/grabfood
    + Mở cmd/Terminal
    + Chạy lệnh npm install để cài đặt các thư viện cần thiết
    + Chạy lệnh ng serve để Angular build và chạy frontend của ứng dụng
    + Truy cập http://localhost:4200 để xem ứng dụng
- Chạy Express Server:
    + Vào thư mục: grabfood/Server/backend
    + Mở cmd/Terminal
    + Chạy lệnh npm install để cài đặt các thư viện cần thiết
    + Chạy lệnh npm start để build và chạy backend của ứng dụng
    + Ứng dụng chạy ở http://localhost:3030
- Máy có cài đặt docker có thể chạy image hieunvce/grabfood:v2